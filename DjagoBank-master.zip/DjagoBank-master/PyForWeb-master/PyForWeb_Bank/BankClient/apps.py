from django.apps import AppConfig


class BankclientConfig(AppConfig):
    name = 'BankClient'
