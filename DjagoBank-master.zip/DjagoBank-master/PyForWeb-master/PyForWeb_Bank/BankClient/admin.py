from django.contrib import admin
from BankClient.models import UserAccount

admin.site.register(UserAccount)
