from django.urls import path
from BankClient import views


urlpatterns = [
    path('', views.index, name="Index"),
    path('transfer', views.transfer, name="Transfer"),
    path('donate', views.donate, name="Donate"),
]