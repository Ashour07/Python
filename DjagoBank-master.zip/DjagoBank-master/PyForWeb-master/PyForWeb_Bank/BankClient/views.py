from django.shortcuts import render
from BankClient.models import UserAccount
from BankClient.forms import Transfer, Donate


def index(request):
    return render(request, "index.html", {"data": UserAccount.objects.all()[0]})


def transfer(request):
    if (request.method == "POST"):
        user_id = int(request.POST.get("user_id"))
        money = int(request.POST.get("money"))
        done = UserAccount.objects.all()[0].takeMoney(money)
        if done:
            check = False
            for user in UserAccount.objects.all():
                if user.userId == user_id:
                    user.addMoney(money)
                    check = True
            if check:
                return render(request, "done.html")
            else:
                return render(request, "fail.html")
        else:
            return render(request, "fail.html")
    else:
        return render(request, "transfer.html", {"form": Transfer})


def donate(request):
    if (request.method == "POST"):
        money = int(request.POST.get("money"))
        done = UserAccount.objects.all()[0].takeMoney(money)
        if done:
            return render(request, "done.html")
        else:
            return render(request, "fail.html")
    else:
        return render(request, "transfer.html", {"form": Donate})
    return render(request, "donate.html")
