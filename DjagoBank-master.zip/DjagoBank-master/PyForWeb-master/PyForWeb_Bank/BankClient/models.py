from django.db import models


class UserAccount(models.Model):
    full_name = models.CharField(max_length=60)
    money = models.PositiveIntegerField()
    userId = models.PositiveIntegerField()

    def addMoney(self, money):
        self.money += money
        self.save()

    def takeMoney(self, money):
        if (self.money - money) < 0:
            return False
        else:
            self.money -= money
            self.save()
            return True
        self.save()

    def __str__(self):
        return self.full_name
