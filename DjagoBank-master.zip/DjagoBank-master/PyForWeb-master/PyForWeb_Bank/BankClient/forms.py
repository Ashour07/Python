from django import forms


class Transfer(forms.Form):
    user_id = forms.IntegerField(max_value=999, label="Id пользователя: ")
    money = forms.IntegerField(label="Количество денег: ")


class Donate(forms.Form):
    money = forms.IntegerField(label="Количество денег: ")
